package math_test;

import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;

public class MathTest {

	private JFrame frame;  											 //���
	private JTextField textField;  									 //�ı��������
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	int r;	
	/*
	 *  Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MathTest window = new MathTest();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/*
	  Create the application.
	 */
	public MathTest() {
		initialize();  												 //��ʼ��
	}

	/*
	  ��ʼ����ܵ�����
	 */
	static int randomnumber1 = (int)(Math.random()*10);
	static int randomnumber2 = (int)(Math.random()*10);
	private void initialize() {
		
		frame = new JFrame();  										 //newһ��JFrame()����
		frame.setBounds(100, 100, 597, 446);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 25));
		textField.setBounds(323, 34, 178, 77);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u8BA1\u7B97");
		btnNewButton.setBounds(77, 312, 164, 63);
		frame.getContentPane().add(btnNewButton);         			  //���������㡱��ť�ļ����¼�
		btnNewButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int result;				
					
				 r = randomnumber1+randomnumber2;
				
				try{
					result = Integer.parseInt(textField.getText());
				 }catch(NumberFormatException ex){
					 System.out.println(ex.getMessage());
					 lblNewLabel.setText("������𰸣�");
					 return;
				 }
				
				 String message = "";
				 if(result == r )
					 message = ("�������������");				 
				 else
					 message = ("����ˣ�����"+r+"! ");
				 lblNewLabel.setText(message);
			}
			
		});
	
		JButton btnNewButton_1 = new JButton("\u4E0B\u4E00\u9898");
		btnNewButton_1.setBounds(337, 312, 164, 63);
		frame.getContentPane().add(btnNewButton_1);					//��������һ�⡱��ť�ļ����¼�
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				randomnumber1 = (int)(Math.random()*10);
				randomnumber2 = (int)(Math.random()*10);
				 r = randomnumber1+randomnumber2;
				 lblNewLabel_1.setText(randomnumber1+"+"+randomnumber2);
			}
		});
		lblNewLabel = new JLabel("��ʾ��");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel.setBounds(89, 121, 424, 140);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel(randomnumber1+"+"+randomnumber2);
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(105, 32, 267, 77);
		frame.getContentPane().add(lblNewLabel_1);
	}

}
