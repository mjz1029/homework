/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : localhost:3306
 Source Schema         : estore

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 23/02/2021 02:19:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `accountid` int(11) NOT NULL AUTO_INCREMENT,
  `balance` float DEFAULT NULL,
  PRIMARY KEY (`accountid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of account
-- ----------------------------
BEGIN;
INSERT INTO `account` VALUES (1, 992097);
COMMIT;

-- ----------------------------
-- Table structure for mycomputers
-- ----------------------------
DROP TABLE IF EXISTS `mycomputers`;
CREATE TABLE `mycomputers` (
  `Id` int(100) NOT NULL AUTO_INCREMENT,
  `Brand` varchar(255) NOT NULL,
  `Model` varchar(255) NOT NULL,
  `Price` float NOT NULL,
  `Publishingdate` date NOT NULL,
  `Salesamount` int(255) NOT NULL,
  `Storenumber` int(255) NOT NULL,
  `Remark` text,
  `Url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of mycomputers
-- ----------------------------
BEGIN;
INSERT INTO `mycomputers` VALUES (1, '三只松鼠', '每日坚果750g/30包', 139, '2021-02-11', 233, 631, '网红爆款零食干果年货大礼包礼盒', 'https://img.alicdn.com/imgextra/i4/880734502/O1CN01d4DCh21j7xhjfScue_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (2, '三只松鼠', '年货坚果大礼包1498g/8袋', 188, '2021-01-22', 432, 646, '网红休闲干果春节零食礼盒\n团圆好礼，佳节必囤，松鼠陪您闹元宵！', 'https://img.alicdn.com/imgextra/i4/880734502/O1CN01tA7hal1j7xjnwHQZC_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (3, '三只松鼠', '夏威夷果265gx2', 57, '2020-12-12', 115, 641, '营养零食小吃坚果仁奶油口味', 'https://img.alicdn.com/imgextra/i2/880734502/O1CN01bFcAZe1j7xhIO63ok_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (4, '三只松鼠', '巨型零食大礼包/30包', 188.8, '2020-12-22', 221, 631, '年货网红猪饲料零食休闲小吃', 'https://img.alicdn.com/imgextra/i3/880734502/O1CN01pkcNpk1j7xcsqehwm_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (5, '三只松鼠', '碧根果160gx2袋', 38, '2021-01-22', 123, 644, '小零食核桃坚果仁奶油味长寿果', 'https://img.alicdn.com/imgextra/i1/880734502/O1CN01WX5VO41j7xjDqnEy2_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (6, '三只松鼠', '手剥巴旦木185gx2', 45, '2021-01-22', 231, 634, '网红休闲吃货零食健康坚果干果仁', 'https://img.alicdn.com/imgextra/i4/880734502/O1CN01aNlftj1j7xhHx1Mb8_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (7, '三只松鼠', '开口松子160gx2袋', 87, '2021-02-11', 123, 543, '东北手剥大颗粒仁原味健康', 'https://img.alicdn.com/imgextra/i2/880734502/O1CN014rum2j1j7xakU3ESf-880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (8, '三只松鼠', '炭烧腰果', 33, '2021-02-11', 123, 541, '越南特产辣味宿舍零食紫皮坚果仁干果', 'https://img.alicdn.com/imgextra/i2/880734502/O1CN01DJzUvL1j7xihlkUUr_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (9, '三只松鼠', '手剥山核桃185g', 66, '2021-02-11', 123, 316, '零食坚果炒货干果临安产奶油味', 'https://img.alicdn.com/imgextra/i2/880734502/O1CN01a3WGEd1j7xhcurtSP_!!880734502.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (10, '百草味 ', '罐装开心果500g', 99, '2021-02-11', 123, 417, '无漂白坚果孕妇零食', 'https://img.alicdn.com/imgextra/i1/6000000002255/O1CN014mbX7l1SWplzI9191_!!6000000002255-2-at.png_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (11, '百草味', '蔬果干礼盒548g', 59, '2021-02-11', 123, 517, '蔬菜脆果蜜饯蔬秋葵香菇', 'https://img.alicdn.com/imgextra/i3/6000000002301/O1CN01hkLB2L1Sru093p1Pl_!!6000000002301-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (12, '百草味', '高端坚果年货礼盒 1480g', 299, '2021-02-11', 123, 419, '全坚果元宵送礼大礼包', 'https://img.alicdn.com/imgextra/i1/6000000002048/O1CN01QOAbSn1R01nZYFgt9_!!6000000002048-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (13, '百草味', '水果干礼盒486g', 45.6, '2021-02-11', 123, 314, '零食大礼包芒果干草莓干蜜饯', 'https://img.alicdn.com/imgextra/i3/6000000003657/O1CN01fsdmZ81csx0xJFtEF_!!6000000003657-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (14, '百草味', '每日抱抱果758g箱', 33, '2021-02-11', 123, 412, '大红枣夹核桃仁果干', 'https://img.alicdn.com/imgextra/i3/6000000006595/O1CN01NmCNv71yaYetZIL1P_!!6000000006595-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (15, '百草味', '熟制板栗仁60g', 12, '2021-02-11', 123, 314, '坚果炒货零食特产甘栗仁', 'https://img.alicdn.com/imgextra/i3/6000000005661/O1CN01u28Jtt1rgmjjo7zB9_!!6000000005661-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (16, '百草味', '多味花生100g', 12, '2021-02-11', 123, 414, '风味特产坚果炒货', 'https://img.alicdn.com/imgextra/i1/6000000006078/O1CN01aG2VWc1ulltZls3aN_!!6000000006078-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (17, '百草味', '百草味荤素大礼包520g', 55, '2021-02-11', 123, 613, '卤味鸭脖休闲肉干零食春节送礼', 'https://img.alicdn.com/imgextra/i3/6000000002624/O1CN01iA8g761VFpvLSrKEU_!!6000000002624-0-at.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (18, '良品铺子', '坚果零食大礼包', 121, '2021-02-11', 123, 423, '每日干果混合装巨型组合', 'https://img.alicdn.com/imgextra/i4/619123122/O1CN01Z8icgG1YvvAnKbBjZ_!!619123122.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (19, '良品铺子', '猪肉脯干', 23, '2021-02-11', 345, 451, '靖江猪肉脯靖江特产', 'https://img.alicdn.com/imgextra/i2/619123122/O1CN01PkFg7I1Yvv88RzI35_!!619123122.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (20, '良品铺子', '巴旦木120gx2袋', 45, '2021-02-11', 123, 415, '巴旦木坚果干果零食手剥', 'https://img.alicdn.com/imgextra/i3/619123122/O1CN01PRXAOz1YvvAw8BnhJ_!!619123122.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (21, '良品铺子', '杏干100g', 23, '2021-02-11', 421, 534, '休闲零食果干果脯蜜饯', 'https://img.alicdn.com/imgextra/i3/619123122/O1CN01DWjZVQ1Yvv2Y2dsE9_!!619123122.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (22, '良品铺子', '花生100g', 12, '2021-02-11', 231, 531, '花生米好吃的零食休闲小吃', 'https://img.alicdn.com/imgextra/i4/619123122/O1CN011YvuywehSaMTTeD_!!619123122.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (23, '良品铺子', '小白杏核200gx2袋', 36, '2021-02-11', 214, 613, '坚果特产零食小吃干果', 'https://img.alicdn.com/imgextra/i1/619123122/O1CN01sS3uTL1Yvv5T6cR1C_!!619123122.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (24, '来伊份', '临安山核桃仁', 55, '2021-02-11', 242, 613, '百年好核坚果坚果', 'https://img.alicdn.com/imgextra/i3/732501769/O1CN011rHq9h1OwFGOwaDl9_!!732501769.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (25, '来伊份', '话梅味花生118g*2', 15, '2021-02-11', 222, 614, '多味花生梅果子炒货', 'https://img.alicdn.com/imgextra/i4/732501769/O1CN01nLuOaZ1OwFGQPEr88_!!732501769.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (26, '来伊份', '香酥豌豆125g*4袋', 16, '2021-02-11', 233, 643, '豆类休闲零食小吃', 'https://img.alicdn.com/imgextra/i4/732501769/O1CN010rKVBw1OwFGtnwiGy_!!732501769.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (27, '来伊份', '坚果塔25g*3', 21, '2021-02-11', 234, 734, '组合核桃干果零食', 'https://img.alicdn.com/imgextra/i1/732501769/O1CN01ZBFgIn1OwFGHpOwq7_!!732501769.jpg_430x430q90.jpg');
INSERT INTO `mycomputers` VALUES (28, '来伊份', '话梅味西瓜子500g', 34, '2021-02-11', 344, 614, '西瓜子休闲零食小吃散装坚果', 'https://img.alicdn.com/imgextra/i1/732501769/O1CN01jDoQ8t1OwFHInTdFl_!!732501769.jpg_430x430q90.jpg');
COMMIT;

-- ----------------------------
-- Table structure for trade
-- ----------------------------
DROP TABLE IF EXISTS `trade`;
CREATE TABLE `trade` (
  `tradeid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `tradetime` datetime NOT NULL,
  PRIMARY KEY (`tradeid`),
  KEY `user_id_fk` (`userid`),
  CONSTRAINT `trade_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `userinfo` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of trade
-- ----------------------------
BEGIN;
INSERT INTO `trade` VALUES (12, 1, '2012-11-01 00:00:00');
INSERT INTO `trade` VALUES (13, 1, '2012-11-01 00:00:00');
INSERT INTO `trade` VALUES (14, 1, '2012-11-01 00:00:00');
INSERT INTO `trade` VALUES (15, 1, '2012-12-20 00:00:00');
INSERT INTO `trade` VALUES (16, 1, '2012-12-20 00:00:00');
INSERT INTO `trade` VALUES (17, 1, '2018-01-16 00:00:00');
INSERT INTO `trade` VALUES (18, 3, '2018-01-16 00:00:00');
INSERT INTO `trade` VALUES (19, 2, '2018-01-16 00:00:00');
INSERT INTO `trade` VALUES (20, 1, '2018-01-17 00:00:00');
INSERT INTO `trade` VALUES (21, 1, '2018-01-17 00:00:00');
INSERT INTO `trade` VALUES (22, 1, '2018-01-17 00:00:00');
INSERT INTO `trade` VALUES (23, 1, '2018-01-17 00:00:00');
INSERT INTO `trade` VALUES (24, 1, '2018-01-17 00:00:00');
INSERT INTO `trade` VALUES (25, 1, '2018-01-17 00:00:00');
INSERT INTO `trade` VALUES (26, 2, '2018-01-19 00:00:00');
INSERT INTO `trade` VALUES (27, 2, '2018-01-19 00:00:00');
INSERT INTO `trade` VALUES (28, 2, '2018-01-19 00:00:00');
INSERT INTO `trade` VALUES (29, 2, '2018-01-19 00:00:00');
INSERT INTO `trade` VALUES (30, 2, '2018-01-19 00:00:00');
INSERT INTO `trade` VALUES (31, 2, '2018-01-19 00:00:00');
INSERT INTO `trade` VALUES (37, 1, '2021-02-23 00:00:00');
INSERT INTO `trade` VALUES (38, 1, '2021-02-23 00:00:00');
INSERT INTO `trade` VALUES (39, 1, '2021-02-23 00:00:00');
COMMIT;

-- ----------------------------
-- Table structure for tradeitem
-- ----------------------------
DROP TABLE IF EXISTS `tradeitem`;
CREATE TABLE `tradeitem` (
  `itemid` int(11) NOT NULL AUTO_INCREMENT,
  `computerid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tradeid` int(11) DEFAULT NULL,
  PRIMARY KEY (`itemid`),
  KEY `book_id_fk` (`computerid`),
  KEY `trade_id_fk` (`tradeid`),
  CONSTRAINT `tradeitem_ibfk_1` FOREIGN KEY (`computerid`) REFERENCES `mycomputers` (`Id`),
  CONSTRAINT `tradeitem_ibfk_2` FOREIGN KEY (`tradeid`) REFERENCES `trade` (`tradeid`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tradeitem
-- ----------------------------
BEGIN;
INSERT INTO `tradeitem` VALUES (22, 19, 10, 12);
INSERT INTO `tradeitem` VALUES (23, 27, 10, 12);
INSERT INTO `tradeitem` VALUES (24, 7, 10, 12);
INSERT INTO `tradeitem` VALUES (25, 1, 1, 13);
INSERT INTO `tradeitem` VALUES (26, 13, 2, 13);
INSERT INTO `tradeitem` VALUES (27, 14, 3, 13);
INSERT INTO `tradeitem` VALUES (28, 15, 4, 13);
INSERT INTO `tradeitem` VALUES (29, 1, 1, 14);
INSERT INTO `tradeitem` VALUES (30, 13, 2, 14);
INSERT INTO `tradeitem` VALUES (31, 14, 3, 14);
INSERT INTO `tradeitem` VALUES (32, 15, 4, 14);
INSERT INTO `tradeitem` VALUES (33, 22, 5, 14);
INSERT INTO `tradeitem` VALUES (34, 23, 5, 14);
INSERT INTO `tradeitem` VALUES (35, 24, 5, 14);
INSERT INTO `tradeitem` VALUES (36, 2, 1, 15);
INSERT INTO `tradeitem` VALUES (37, 1, 2, 15);
INSERT INTO `tradeitem` VALUES (38, 3, 1, 15);
INSERT INTO `tradeitem` VALUES (39, 2, 1, 16);
INSERT INTO `tradeitem` VALUES (40, 1, 3, 16);
INSERT INTO `tradeitem` VALUES (41, 3, 1, 16);
INSERT INTO `tradeitem` VALUES (47, 1, 1, 19);
INSERT INTO `tradeitem` VALUES (48, 2, 1, 19);
INSERT INTO `tradeitem` VALUES (49, 3, 1, 19);
INSERT INTO `tradeitem` VALUES (50, 1, 1, 27);
INSERT INTO `tradeitem` VALUES (51, 6, 1, 27);
INSERT INTO `tradeitem` VALUES (52, 2, 1, 28);
INSERT INTO `tradeitem` VALUES (53, 6, 1, 29);
INSERT INTO `tradeitem` VALUES (54, 2, 1, 30);
INSERT INTO `tradeitem` VALUES (55, 20, 1, 31);
INSERT INTO `tradeitem` VALUES (56, 11, 1, 31);
COMMIT;

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `accountid` int(11) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `account_id_fk` (`accountid`),
  CONSTRAINT `userinfo_ibfk_1` FOREIGN KEY (`accountid`) REFERENCES `account` (`accountid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
BEGIN;
INSERT INTO `userinfo` VALUES (1, 'Tom', 1);
INSERT INTO `userinfo` VALUES (2, 'AAA', 1);
INSERT INTO `userinfo` VALUES (3, 'BB', 1);
INSERT INTO `userinfo` VALUES (4, 'CC', 1);
INSERT INTO `userinfo` VALUES (5, 'DD', 1);
INSERT INTO `userinfo` VALUES (6, 'EE', 1);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
