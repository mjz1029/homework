package com.bookface;

public class MenuMainFrame {

	// �������
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookMenuFram menu = new BookMenuFram();
		menu.BookMenuFram();
	}

}
